#ifndef HARDWARE_RESET_H
#define HARDWARE_RESET_H

#ifdef __cplusplus
extern "C" {
#endif

void hardware_reset(void) __attribute__((noreturn));

#ifdef __cplusplus
}
#endif

#endif
